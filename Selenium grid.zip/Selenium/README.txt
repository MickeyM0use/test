1. Put Folder Selenium into C:\
2. Execute HUB.bat (don't close console window)
3. NODE.bat (don't close console window)
4. Start executing your tests using command mvn clean verify